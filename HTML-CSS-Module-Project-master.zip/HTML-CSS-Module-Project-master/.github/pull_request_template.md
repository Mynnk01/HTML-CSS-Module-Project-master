<!--

The title for your pull request should be made in this format

CITY CLASS_NO - FIRST_NAME LAST_NAME - MODULE - WEEK_NO

For example,

London Class 7 - Chris Owen - HTML/CSS - Week 1

Please complete the details below this message

-->

**Volunteers: Are you marking this coursework?** _You can find a guide on how to mark this coursework in `HOW_TO_MARK.md` in the root of this repository_

# Your Details

- Your Name:
- Your City:
- Your Slack Name:

# Homework Details

- Module:
- Week:

# Notes

- What did you find easy?

- What did you find hard?

- What do you still not understand?

- Any other notes?
